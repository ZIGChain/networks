# ZIGChain

**ZIGChain** is a blockchain built using Cosmos SDK and CometBFT.

## Prerequisites

Before you can build and run zigchain, you need to install the following dependencies:

### 1. Install Go (Latest Version)

**macOS:**
```bash
# Using Homebrew (recommended)
brew install go

# Or download from golang.org
# Visit https://golang.org/dl/ and download the latest version for macOS
```

**Linux:**
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install golang-go

# Or download from golang.org
wget https://go.dev/dl/go1.24.0.linux-amd64.tar.gz
sudo tar -C /usr/local -xzf go1.24.0.linux-amd64.tar.gz
```

**Verify Go installation:**
```bash
go version
```

### 2. Install Ignite v28

**macOS:**
```bash
# Download and install Ignite v28.10.0 for macOS (Apple Silicon)
curl -L https://github.com/ignite/cli/releases/download/v28.10.0/ignite_28.10.0_darwin_arm64.tar.gz -o ignite.tar.gz
tar -xzf ignite.tar.gz
sudo mv ignite /usr/local/bin/
rm ignite.tar.gz
```

**Linux:**
```bash
# Download and install Ignite v28.10.0 for Linux
curl -L https://github.com/ignite/cli/releases/download/v28.10.0/ignite_28.10.0_linux_amd64.tar.gz -o ignite.tar.gz
tar -xzf ignite.tar.gz
sudo mv ignite /usr/local/bin/
rm ignite.tar.gz
```

**Verify Ignite installation:**
```bash
ignite version
# Should show v28.10.0
```

### 3. Set up Go Environment

You need to add Go's bin directory to your PATH so you can run Go binaries from anywhere.

**macOS:**
```bash
# Add to your shell profile (~/.zshrc for zsh, ~/.bash_profile for bash)
echo 'export GOPATH=$HOME/go' >> ~/.zshrc
echo 'export PATH=$PATH:$GOPATH/bin' >> ~/.zshrc
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.zshrc

# Reload your shell configuration
source ~/.zshrc
```

**Linux:**
```bash
# Add to your shell profile (~/.bashrc for bash, ~/.zshrc for zsh)
echo 'export GOPATH=$HOME/go' >> ~/.bashrc
echo 'export PATH=$PATH:$GOPATH/bin' >> ~/.bashrc
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc

# Reload your shell configuration
source ~/.bashrc
```

**Verify PATH setup:**
```bash
echo $PATH | grep go
# Should show /usr/local/go/bin and ~/go/bin in the output
```

## Building from Source

Once you have all dependencies installed, you can build the zigchain binary:

```bash
# Clone the repository (if you haven't already)
git clone <repository-url>
cd zigchain

# Build and install the binary
make install
```

This will:
1. Check that you have the required Go version (1.24+)
2. Download and verify dependencies
3. Build the `zigchaind` binary
4. Install it to `~/go/bin/zigchaind`

**Verify the installation:**
```bash
zigchaind version
```

## Development

```
ignite chain serve
```

`serve` command installs dependencies, builds, initializes, and starts your blockchain in development.

## Configure

Your blockchain in development can be configured with `config.yml`. To learn more, see the [Ignite CLI docs](https://docs.ignite.com).

## Full Documentation 

You can see full documentation in docs subdirectory.

## Release
To release a new version of your blockchain, create and push a new tag with `v` prefix. A new draft release with the configured targets will be created.

```
git tag v0.1
git push origin v0.1
```

After a draft release is created, make your final changes from the release page and publish it.

## Development Tools

To install `mockgen`, which is used for generating mocks in Go, follow these steps:

1. **Ensure Go is installed**: Verify that you have Go installed by running `go version`. If not, install it from [golang.org](https://golang.org/dl/).

2. **Install mockgen**:
   Run the following command to install `mockgen`:
   ```bash
   go install go.uber.org/mock/mockgen@latest
   ```

3. **Verify installation**:
   Check if `mockgen` is installed by running:
   ```bash
   mockgen --version
   ```
   This should display the version of `mockgen`.

4. **Run the following script to generate mock files**:
   ```bash
   ./sh/mockgen.sh
   ```

### Notes:
- If you encounter issues, ensure your Go environment is set up correctly (`GOPATH`, `GOBIN`, etc.).
- Make sure `~/go/bin` is in your PATH as described in the prerequisites section.